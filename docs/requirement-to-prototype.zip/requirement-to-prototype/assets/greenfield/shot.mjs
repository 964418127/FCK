/**
 * 文档截图脚本（最小实现，跨项目可复制）。
 *
 * 用法：
 *   node scripts/shot.mjs "<url>" <out.png> [宽=1560] [高=940] [等待ms=1500] [缩放=2]
 *   例：node scripts/shot.mjs "http://localhost:5173/orders?shot=1" src/docs/assets/pages/orders.png
 *
 * 依赖：puppeteer-core（npm i -D puppeteer-core）
 * 浏览器：默认用系统 Chrome，可用 CHROME_PATH 环境变量覆盖。
 * 前置：先起开发服务器；页面需支持 ?shot=1 隐藏框架。
 */
import { existsSync } from 'node:fs'

let puppeteer
try {
  puppeteer = (await import('puppeteer-core')).default
} catch {
  console.error('[shot] 缺少依赖，请先在项目内安装：npm i -D puppeteer-core')
  process.exit(1)
}

const CHROME_CANDIDATES = [
  process.env.CHROME_PATH,
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  '/Applications/Chromium.app/Contents/MacOS/Chromium',
  '/usr/bin/google-chrome',
  '/usr/bin/chromium',
  '/usr/bin/chromium-browser',
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
].filter(Boolean)

const executablePath = CHROME_CANDIDATES.find(p => {
  try { return existsSync(p) } catch { return false }
})

if (!executablePath) {
  console.error('[shot] 未找到 Chrome，请设置 CHROME_PATH 环境变量指向浏览器可执行文件')
  process.exit(1)
}

const [, , url, out, w = '1560', h = '940', wait = '1500', scale = '2'] = process.argv
if (!url || !out) {
  console.error('用法: node scripts/shot.mjs <url> <out.png> [宽] [高] [等待ms] [缩放]')
  process.exit(1)
}

const browser = await puppeteer.launch({
  executablePath,
  headless: 'new',
  args: ['--no-sandbox', '--disable-gpu', '--hide-scrollbars', `--window-size=${w},${h}`]
})

try {
  const page = await browser.newPage()
  await page.setViewport({ width: +w, height: +h, deviceScaleFactor: +scale })
  await page.goto(url, { waitUntil: 'networkidle2', timeout: 30000 })
    .catch(e => console.warn('[shot] networkidle2 超时，降级继续:', e.message))
  await new Promise(r => setTimeout(r, +wait))
  await page.screenshot({ path: out })
  console.log('[shot] 已输出', out)
} finally {
  await browser.close()
}
