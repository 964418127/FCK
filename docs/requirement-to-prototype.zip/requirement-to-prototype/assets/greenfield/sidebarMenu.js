/**
 * 侧边栏菜单数据源（模板）。
 *
 * 铁律：菜单在这里声明，布局用 v-for 渲染，不要手写菜单模板。
 * 手写模板会让「排序 / 显隐 / 权限」后续全部落不了地。
 *
 * 节点结构：
 *   { index, label, icon?, to?, children? }
 *   - index    与路由 name 一致；分组节点的 index 只是分组标识
 *   - icon     图标组件引用（渲染：<component :is="node.icon" />）
 *   - to       可选的跳转目标（部分菜单组件按 to 跳转）
 *   - children 有则是分组（展开），没有则是可点页面
 */
import { HomeFilled, Document, Setting, List } from '@element-plus/icons-vue'

export const sidebarMenu = [
  { index: 'welcome', label: '欢迎页', icon: HomeFilled },

  // 文档中心通常是独立布局的入口，index 即路由 name
  { index: 'docs', label: '文档中心', icon: Document },

  {
    index: 'g-business',
    label: '业务配置',
    icon: Setting,
    children: [
      { index: 'order-list', label: '订单列表', icon: List }
    ]
  }
]
