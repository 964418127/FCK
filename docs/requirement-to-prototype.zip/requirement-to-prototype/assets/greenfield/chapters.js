/**
 * 文档模块的章节元数据（模板）。
 *
 * 单一数据源：同一份数组同时派生「文档中心左侧菜单」与「文档中心路由」。
 * 改一处，菜单与路由自动同步，不会分叉。
 *
 * 字段：
 *   id        短标识（url 段）
 *   order     序号（一/二/…）
 *   title     章节标题（菜单与页面标题）
 *   subtitle  副标题（章节描述）
 *   routeName vue-router 路由 name（同时作为菜单 index）
 *   path      路由 path
 *   file      子页 SFC 文件名（放在对应 views 目录）
 */
export const demoChapters = [
  {
    id: 'overview',
    order: '一',
    title: '需求说明',
    subtitle: '版本信息 + 变更日志 + 需求背景 + 需求范围 + 功能详细说明 + 待决事项',
    routeName: 'doc-demo-overview',
    path: '/docs/demo/overview',
    file: 'DemoOverview.vue'
  }
]

/*
 * 接线路由（router/routes.js）：
 *   import { demoChapters } from '../docs/demoChapters.js'
 *   const modules = import.meta.glob('../views/demo-guide/*.vue')
 *   ...demoChapters.map(ch => ({
 *     path: ch.path, name: ch.routeName, component: modules[`../views/demo-guide/${ch.file}`]
 *   }))
 *
 * 接线路由菜单（docs/menu.js）：
 *   import { demoChapters } from './demoChapters.js'
 *   const demoMenuChildren = demoChapters.map(ch => ({
 *     index: ch.routeName, label: `${ch.order}、${ch.title}`
 *   }))
 *
 * 两处都从同一数组派生 —— 只改一处会造成菜单与路由分叉。
 */
