# 跨工具挂载说明

本技能是**纯 Markdown 指令包**（SKILL.md + references），不含任何特定工具的 API 调用，因此可挂载到任何支持 Agent Skills 规范（YAML frontmatter + Markdown 正文）的工具。

## 目录结构

```
requirement-to-prototype/
├── SKILL.md                          # 主流程（frontmatter: name/description）
└── references/
    ├── stage-guide.md                # 各阶段详细操作指引 + 默认约定
    ├── kickoff-checklist.md          # 开工确认单模板
    └── portability.md                # 本文件
```

## 各工具挂载位置

| 工具 | 用户级位置 | 项目级位置 |
|------|-----------|-----------|
| WorkBuddy | `~/.workbuddy/skills/requirement-to-prototype/` | `<项目>/.workbuddy/skills/requirement-to-prototype/` |
| Claude Code | `~/.claude/skills/requirement-to-prototype/` | `<项目>/.claude/skills/requirement-to-prototype/` |
| Zcode 及其他兼容 Agent Skills 规范的工具 | 其文档所述 skills 目录 | 项目内 skills 目录 |

同一份技能目录可直接复制到多处，或用符号链接保持同步：

```bash
ln -s ~/.workbuddy/skills/requirement-to-prototype ~/.claude/skills/requirement-to-prototype
```

## 无技能机制的工具：降级用法

若目标工具不识别技能目录，有两种降级方式：

1. **Prompt 前缀**：把 SKILL.md 全文粘贴进系统提示 / 项目指令（如 `AGENTS.md`、`.cursorrules`、项目 CLAUDE.md），并将 references 三份文件放入项目任意目录，正文中把 `references/...` 路径改为实际路径
2. **项目约定文件**：把 SKILL.md 的「核心原则 + 流程总览」压缩进项目的 `PROD-CONVENTIONS.md`（本技能运行时会自动探测该文件），技能退化为纯约定文档也能生效

## 项目约定注入点

技能刻意不内置任何具体项目的「原型规范 / 文档规范」。运行时按以下顺序探测：

1. `<项目>/.workbuddy/PROD-CONVENTIONS.md`（推荐放置处）
2. `PRODUCT.md`
3. `docs/` 下规范类文档
4. 都没有 → 使用 `references/stage-guide.md` 末尾的默认约定，并提示用户补充

因此换项目时**只改约定文件，不改技能本体**；换工具时**只挪目录，不改内容**。
